import 'package:flutter/material.dart';

const kBg = Color(0xFF050608);
const kCard = Color(0xFF111318);
const kCyan = Color(0xFF00D9FF);
const kPink = Color(0xFFFF285F);
const kPurple = Color(0xFF8B5CFF);
const kGold = Color(0xFFFFC94A);

void main() => runApp(const NApp());

class NApp extends StatelessWidget {
  const NApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'N',
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: kBg,
          colorScheme: ColorScheme.fromSeed(seedColor: kCyan, brightness: Brightness.dark),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: kCard,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
          ),
          cardTheme: CardThemeData(
            color: kCard,
            margin: EdgeInsets.zero,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          ),
          navigationBarTheme: const NavigationBarThemeData(
            backgroundColor: Color(0xFF07080B),
            indicatorColor: Color(0x3300D9FF),
          ),
        ),
        home: const AuthPage(),
      );
}

class NPost {
  NPost({required this.author, required this.handle, required this.caption, this.adult = false});
  final String author, handle, caption;
  final bool adult;
  int likes = 128600, comments = 3245, shares = 5732, saves = 12400;
  bool liked = false, saved = false;
}

class NStore extends ChangeNotifier {
  String name = '', username = '', email = '', bio = 'مرحباً بك في N ✨';
  int age = 0, coins = 12560;
  bool loggedIn = false;
  final posts = <NPost>[
    NPost(author: 'N Official', handle: '@N_Official', caption: 'الليلة مختلفة دائماً ... ✨\n#N_Moments'),
    NPost(author: 'سجاد', handle: '@sajjad', caption: 'اصنع لحظتك بنفسك 🔥'),
    NPost(author: 'علي', handle: '@ali', caption: 'كل يوم بداية جديدة في N.'),
  ];
  final following = <String>{};
  bool get adultEligible => age >= 21;
  void login(String n, String u, String e, int a) { name=n; username=u; email=e; age=a; loggedIn=true; notifyListeners(); }
  void addPost(String text, bool adult) { posts.insert(0, NPost(author:name.isEmpty?'N User':name, handle:'@${username.isEmpty?'n_user':username}', caption:text, adult:adult)); notifyListeners(); }
  void toggleFollow(String handle) { following.contains(handle) ? following.remove(handle) : following.add(handle); notifyListeners(); }
  void addCoins(int amount) { coins += amount; notifyListeners(); }
  void logout() { loggedIn=false; notifyListeners(); }
}
final n = NStore();

class NLogo extends StatelessWidget {
  const NLogo({super.key, this.size=58});
  final double size;
  @override Widget build(BuildContext context) => Container(
    width:size, height:size,
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(size*.28), gradient: const LinearGradient(colors:[kCyan,kPink])),
    child: Center(child: Text('N', style: TextStyle(fontSize:size*.62, fontWeight:FontWeight.w900))),
  );
}

class AuthPage extends StatefulWidget { const AuthPage({super.key}); @override State<AuthPage> createState()=>_AuthPageState(); }
class _AuthPageState extends State<AuthPage> {
  bool signup=true, hide=true;
  final name=TextEditingController(), user=TextEditingController(), email=TextEditingController(), pass=TextEditingController();
  DateTime? dob;
  @override void dispose(){name.dispose();user.dispose();email.dispose();pass.dispose();super.dispose();}
  int calcAge(DateTime d){final now=DateTime.now();var a=now.year-d.year;if(DateTime(now.year,d.month,d.day).isAfter(now))a--;return a;}
  void snack(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));
  Future<void> chooseDob() async {final d=await showDatePicker(context:context,initialDate:DateTime(2000),firstDate:DateTime(1900),lastDate:DateTime.now(),helpText:'اختر تاريخ الميلاد');if(d!=null)setState(()=>dob=d);}
  void submit(){
    final u=user.text.trim().replaceFirst('@','').replaceAll(' ','').toLowerCase();
    if(signup&&name.text.trim().isEmpty)return snack('اكتب الاسم الكامل');
    if(u.length<4)return snack('اسم المستخدم يجب أن يكون 4 أحرف فأكثر');
    if(!RegExp(r'^[a-zA-Z0-9_.]+$').hasMatch(u))return snack('استخدم الأحرف الإنجليزية والأرقام و _ .');
    if(!email.text.contains('@'))return snack('أدخل بريداً إلكترونياً صحيحاً');
    if(pass.text.length<6)return snack('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
    if(signup&&dob==null)return snack('اختر تاريخ الميلاد');
    final a=signup?calcAge(dob!):25;if(signup&&a<13)return snack('يجب أن يكون العمر 13 سنة أو أكثر');
    n.login(signup?name.text.trim():'N User',u,email.text.trim(),a);
    Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const MainShell()));
  }
  @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(22),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:470),child:Column(children:[
    const NLogo(size:90),const SizedBox(height:18),Text('مرحباً بك في N',style:TextStyle(fontSize:29,fontWeight:FontWeight.w900)),const SizedBox(height:6),Text('أنشئ حسابك وابدأ رحلتك',style:TextStyle(color:Colors.white54)),const SizedBox(height:28),
    if(signup)...[TextField(controller:name,decoration:const InputDecoration(labelText:'الاسم الكامل',prefixIcon:Icon(Icons.person_outline))),const SizedBox(height:12)],
    TextField(controller:user,decoration:const InputDecoration(labelText:'اسم المستخدم',hintText:'@username',prefixIcon:Icon(Icons.alternate_email))),const SizedBox(height:12),
    TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'البريد الإلكتروني',prefixIcon:Icon(Icons.email_outlined))),const SizedBox(height:12),
    TextField(controller:pass,obscureText:hide,onSubmitted:(_)=>submit(),decoration:InputDecoration(labelText:'كلمة المرور',prefixIcon:const Icon(Icons.lock_outline),suffixIcon:IconButton(onPressed:()=>setState(()=>hide=!hide),icon:Icon(hide?Icons.visibility:Icons.visibility_off)))),
    if(signup)...[const SizedBox(height:12),OutlinedButton.icon(onPressed:chooseDob,icon:const Icon(Icons.calendar_month),label:Text(dob==null?'تاريخ الميلاد':'${dob!.year}/${dob!.month}/${dob!.day}'))],
    const SizedBox(height:20),SizedBox(width:double.infinity,child:FilledButton(onPressed:submit,child:Padding(padding:const EdgeInsets.all(14),child:Text(signup?'إنشاء الحساب':'تسجيل الدخول',style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900))))),
    TextButton(onPressed:()=>setState(()=>signup=!signup),child:Text(signup?'لدي حساب؟ تسجيل الدخول':'ليس لدي حساب؟ إنشاء حساب')),const SizedBox(height:8),const Text('اسم المستخدم: 4 أحرف فأكثر • المحتوى +21 محمي بالعمر',textAlign:TextAlign.center,style:TextStyle(color:Colors.white38,fontSize:12))
  ])))))));
}

class MainShell extends StatefulWidget { const MainShell({super.key}); @override State<MainShell> createState()=>_MainShellState(); }
class _MainShellState extends State<MainShell>{
  int index=0;
  final pages=const[HomePage(),ExplorePage(),CreatePage(),MessagesPage(),ProfilePage()];
  @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(body:IndexedStack(index:index,children:pages),bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations:const[
    NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'الرئيسية'),
    NavigationDestination(icon:Icon(Icons.grid_view_outlined),selectedIcon:Icon(Icons.grid_view),label:'المنشورات'),
    NavigationDestination(icon:Icon(Icons.add_circle_outline),selectedIcon:Icon(Icons.add_circle),label:'نشر'),
    NavigationDestination(icon:Icon(Icons.chat_bubble_outline),selectedIcon:Icon(Icons.chat_bubble),label:'الرسائل'),
    NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'الملف الشخصي'),
  ])));
}

class HomePage extends StatefulWidget{const HomePage({super.key});@override State<HomePage> createState()=>_HomePageState();}
class _HomePageState extends State<HomePage>{
  int likes=128600; bool liked=false,saved=false;
  @override Widget build(BuildContext context)=>Stack(children:[
    Positioned.fill(child:Image.asset('assets/n_hero.jpg',fit:BoxFit.cover)),
    Positioned.fill(child:DecoratedBox(decoration:BoxDecoration(gradient:LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,colors:[Colors.black.withValues(alpha: .72),Colors.transparent,Colors.black.withValues(alpha: .92)],stops:const[0,.38,.95])))),
    SafeArea(child:Column(children:[
      Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:10),child:Row(children:[const NLogo(size:54),const Spacer(),const _TopTab('متابعة',false),const SizedBox(width:30),const _TopTab('لك',true),const SizedBox(width:15),IconButton(onPressed:()=>showSearch(context: context, delegate: _NSearchDelegate()),icon:const Icon(Icons.search,size:31))])),
      SizedBox(height:105,child:ListView(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:16),children:[_Story('بث مباشر',live:true,onTap:()=>_live(context)),_Story('إضافة قصة',add:true),_Story('سجاد'),_Story('علي'),_Story('مريم'),_Story('عرض الكل',more:true)])),
      const Spacer(),
      Align(alignment:Alignment.centerRight,child:Padding(padding:const EdgeInsets.only(right:14),child:Column(children:[_SideAction(Icons.favorite,liked?'128.6K':'128.6K',onTap:(){setState((){liked=!liked;likes+=liked?1:-1;});}),_SideAction(Icons.mode_comment,'3,245',onTap:()=>_comments(context)),_SideAction(Icons.reply,'5,732',onTap:()=>_share(context)),_SideAction(saved?Icons.bookmark:Icons.bookmark_border,'12.4K',onTap:()=>setState(()=>saved=!saved)),const CircleAvatar(radius:27,backgroundColor:Colors.black87,child:NLogo(size:45))]))),
      Align(alignment:Alignment.centerLeft,child:Padding(padding:const EdgeInsets.fromLTRB(22,0,92,115),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:6),decoration:BoxDecoration(color:Colors.black54,borderRadius:BorderRadius.circular(14)),child:const Text('✨ تأثيرات N')),const SizedBox(height:7),const Row(children:[Text('@N_Official',style:TextStyle(fontWeight:FontWeight.w900,fontSize:16)),SizedBox(width:5),Icon(Icons.verified,color:kCyan,size:17)]),const SizedBox(height:5),const Text('الليلة مختلفة دائماً ... ✨',style:TextStyle(fontSize:17)),const Text('#N_Moments',style:TextStyle(color:kCyan,fontWeight:FontWeight.w700)),const Text('♫  الصوت الأصلي - N',style:TextStyle(color:Colors.white70))]))),
    ])),
    Positioned(bottom:0,left:0,right:0,child:Container(height:108,decoration:BoxDecoration(color:Colors.black.withValues(alpha: .88),borderRadius:const BorderRadius.vertical(top:Radius.circular(28))),child:Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[_Quick(Icons.videocam_outlined,'بث مباشر',onTap:()=>_live(context)),_Quick(Icons.auto_awesome,'تأثيرات'),_Quick(Icons.image_outlined,'رفع'),_Quick(Icons.video_camera_front_outlined,'تصوير',big:true,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CreatePage()))),_Quick(Icons.collections_outlined,'قوالب')]))),
  ]);
  void _comments(BuildContext c)=>showModalBottomSheet(context:c,isScrollControlled:true,backgroundColor:kCard,builder:(_)=>const _Comments());
  void _share(BuildContext c)=>showModalBottomSheet(context:c,backgroundColor:kCard,builder:(_)=>SafeArea(child:Wrap(children:[const ListTile(title:Text('مشاركة المنشور',style:TextStyle(fontWeight:FontWeight.bold))),ListTile(leading:const Icon(Icons.link),title:const Text('نسخ الرابط'),onTap:()=>Navigator.pop(c)),ListTile(leading:const Icon(Icons.send),title:const Text('إرسال إلى صديق'),onTap:()=>Navigator.pop(c))])));
  void _live(BuildContext c)=>showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('البث المباشر'),content:const Text('واجهة البث المباشر جاهزة. يلزم ربط مزود بث حقيقي قبل النشر التجاري.'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إغلاق'))]));
}
class _TopTab extends StatelessWidget{const _TopTab(this.t,this.active);final String t;final bool active;@override Widget build(BuildContext c)=>Column(children:[Text(t,style:TextStyle(fontSize:18,fontWeight:active?FontWeight.w900:FontWeight.w600,color:active?Colors.white:Colors.white54)),if(active)Container(width:43,height:3,margin:const EdgeInsets.only(top:6),decoration:BoxDecoration(gradient:const LinearGradient(colors:[kCyan,kPink]),borderRadius:BorderRadius.circular(4))) ]);}
class _Story extends StatelessWidget{const _Story(this.t,{this.live=false,this.add=false,this.more=false,this.onTap});final String t;final bool live,add,more;final VoidCallback? onTap;@override Widget build(BuildContext c)=>GestureDetector(onTap:onTap,child:Container(width:82,margin:const EdgeInsets.only(right:7),child:Column(children:[Container(width:67,height:67,padding:const EdgeInsets.all(2),decoration:const BoxDecoration(shape:BoxShape.circle,gradient:LinearGradient(colors:[kCyan,kPink])),child:Container(decoration:const BoxDecoration(shape:BoxShape.circle,color:Color(0xFF1B1D22)),child:Center(child:more?const Icon(Icons.chevron_left):add?const Icon(Icons.person_add_alt_1):live?const Icon(Icons.add,size:30):const Text('N',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900))))),if(live)Container(transform:Matrix4.translationValues(0,-6,0),padding:const EdgeInsets.symmetric(horizontal:6,vertical:2),decoration:BoxDecoration(color:kPink,borderRadius:BorderRadius.circular(6)),child:const Text('LIVE',style:TextStyle(fontSize:9,fontWeight:FontWeight.w900))),Text(t,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:12))])));}
class _SideAction extends StatelessWidget{const _SideAction(this.icon,this.text,{this.onTap});final IconData icon;final String text;final VoidCallback? onTap;@override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.only(bottom:15),child:GestureDetector(onTap:onTap,child:Column(children:[Icon(icon,size:34),const SizedBox(height:2),Text(text,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w700))])));}
class _Quick extends StatelessWidget{const _Quick(this.icon,this.text,{this.big=false,this.onTap});final IconData icon;final String text;final bool big;final VoidCallback? onTap;@override Widget build(BuildContext c)=>GestureDetector(onTap:onTap,child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Container(width:big?62:52,height:big?62:52,decoration:BoxDecoration(shape:BoxShape.circle,color:const Color(0xFF17191E),border:big?Border.all(color:Colors.white,width:2):null),child:Icon(icon,size:big?31:26,color:big?kPink:kCyan)),const SizedBox(height:4),Text(text,style:const TextStyle(fontSize:11))]));}
class _Comments extends StatelessWidget{const _Comments();@override Widget build(BuildContext c)=>Padding(padding:EdgeInsets.only(bottom:MediaQuery.of(c).viewInsets.bottom),child:Column(mainAxisSize:MainAxisSize.min,children:[const Padding(padding:EdgeInsets.all(16),child:Text('التعليقات',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900))),const ListTile(leading:CircleAvatar(child:Text('س')),title:Text('سجاد'),subtitle:Text('تصميم N رائع 🔥')),const ListTile(leading:CircleAvatar(child:Text('م')),title:Text('مريم'),subtitle:Text('استمروا 👏')),const Padding(padding:EdgeInsets.all(12),child:TextField(decoration:InputDecoration(hintText:'اكتب تعليقك...',suffixIcon:Icon(Icons.send))))]));}

class _NSearchDelegate extends SearchDelegate<String> {
  final _items = const ['سجاد', 'علي', 'مريم', 'حسين', 'نور', 'فاطمة', 'N Official'];
  @override List<Widget> buildActions(BuildContext context) => [IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];
  @override Widget buildLeading(BuildContext context) => IconButton(onPressed: () => close(context, ''), icon: const Icon(Icons.arrow_back));
  @override Widget buildResults(BuildContext context) => _results(context);
  @override Widget buildSuggestions(BuildContext context) => _results(context);
  Widget _results(BuildContext context) {
    final results = _items.where((x) => query.isEmpty || x.contains(query)).toList();
    return ListView(children: results.map((x) => ListTile(title: Text(x), onTap: () => close(context, x))).toList());
  }
}

class ExplorePage extends StatefulWidget{const ExplorePage({super.key});@override State<ExplorePage> createState()=>_ExplorePageState();}
class _ExplorePageState extends State<ExplorePage>{final q=TextEditingController();final users=const['سجاد','علي','مريم','حسين','نور','فاطمة'];@override void dispose(){q.dispose();super.dispose();}@override Widget build(BuildContext c){final list=users.where((u)=>q.text.isEmpty||u.contains(q.text)).toList();return ListView(padding:const EdgeInsets.fromLTRB(16,48,16,25),children:[const Text('المنشورات',style:TextStyle(fontSize:29,fontWeight:FontWeight.w900)),const SizedBox(height:14),TextField(controller:q,onChanged:(_)=>setState((){}),decoration:const InputDecoration(hintText:'ابحث عن أشخاص أو محتوى',prefixIcon:Icon(Icons.search))),const SizedBox(height:20),const Text('اقتراحات الحسابات',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:8),...list.map((u){final h='@${u.toLowerCase()}';final f=n.following.contains(h);return Card(child:ListTile(leading:const CircleAvatar(child:NLogo(size:34)),title:Text(u),subtitle:Text(h),trailing:FilledButton(onPressed:(){n.toggleFollow(h);},child:Text(f?'متابَع':'متابعة'))));}),const SizedBox(height:20),const Text('الرائج الآن',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),...List.generate(7,(i)=>ListTile(leading:const Icon(Icons.local_fire_department,color:kPink),title:Text('#N_مومنتس_${i+1}'),subtitle:Text('${12+i*3}K منشور')))]);}}

class CreatePage extends StatefulWidget{const CreatePage({super.key});@override State<CreatePage> createState()=>_CreatePageState();}
class _CreatePageState extends State<CreatePage>{final text=TextEditingController();bool adult=false;String privacy='عام';@override void dispose(){text.dispose();super.dispose();}@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.fromLTRB(16,48,16,30),children:[const Text('نشر',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),const SizedBox(height:16),Container(height:190,decoration:BoxDecoration(color:kCard,borderRadius:BorderRadius.circular(24)),child:TextField(controller:text,maxLines:null,expands:true,maxLength:1000,textAlignVertical:TextAlignVertical.top,decoration:const InputDecoration(hintText:'ماذا تريد أن تشارك؟',border:InputBorder.none,contentPadding:EdgeInsets.all(18))),),const SizedBox(height:12),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:()=>_media('صورة'),icon:const Icon(Icons.image_outlined),label:const Text('صورة'))),const SizedBox(width:10),Expanded(child:OutlinedButton.icon(onPressed:()=>_media('فيديو'),icon:const Icon(Icons.videocam_outlined),label:const Text('فيديو')))]),const SizedBox(height:12),DropdownButtonFormField<String>(initialValue:privacy,decoration:const InputDecoration(labelText:'الخصوصية'),items:const[DropdownMenuItem(value:'عام',child:Text('عام')),DropdownMenuItem(value:'المتابعون',child:Text('المتابعون')),DropdownMenuItem(value:'خاص',child:Text('خاص'))],onChanged:(v)=>setState(()=>privacy=v!)),SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('محتوى للبالغين +21'),subtitle:const Text('يظهر فقط للحسابات المؤهلة بالعمر'),value:adult,onChanged:(v){if(v&&!n.adultEligible){ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('هذا الخيار متاح لمن عمره 21 سنة فأكثر')));return;}setState(()=>adult=v);}),const SizedBox(height:10),FilledButton.icon(onPressed:(){if(text.text.trim().isEmpty){ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('اكتب محتوى قبل النشر')));return;}n.addPost(text.text.trim(),adult);text.clear();setState(()=>adult=false);ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('تم نشر المنشور')));},icon:const Icon(Icons.send),label:const Padding(padding:EdgeInsets.all(13),child:Text('نشر الآن',style:TextStyle(fontWeight:FontWeight.w900))))]);void _media(String t)=>showModalBottomSheet(context:context,backgroundColor:kCard,builder:(_)=>SafeArea(child:Wrap(children:[ListTile(leading:Icon(t=='صورة'?Icons.photo_library:Icons.video_library),title:Text('اختيار $t من الجهاز'),onTap:(){Navigator.pop(context);ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('واجهة اختيار $t جاهزة للربط بمكتبة الجهاز')));}),const ListTile(leading:Icon(Icons.camera_alt),title:Text('الكاميرا'))])));}

class MessagesPage extends StatelessWidget{const MessagesPage({super.key});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.fromLTRB(16,48,16,20),children:[const Text('الرسائل',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),const SizedBox(height:15),const TextField(decoration:InputDecoration(hintText:'بحث في الرسائل',prefixIcon:Icon(Icons.search))),const SizedBox(height:10),...['سجاد','مريم','علي','نور'].map((u)=>ListTile(onTap:()=>showDialog(context:c,builder:(_)=>ChatDialog(name:u)),leading:const CircleAvatar(child:NLogo(size:34)),title:Text(u),subtitle:const Text('آخر محادثة — اضغط للفتح'),trailing:const Icon(Icons.chevron_left)))]);}
class ChatDialog extends StatefulWidget{const ChatDialog({super.key,required this.name});final String name;@override State<ChatDialog> createState()=>_ChatDialogState();}
class _ChatDialogState extends State<ChatDialog>{final controller=TextEditingController();final messages=<String>[];@override void dispose(){controller.dispose();super.dispose();}@override Widget build(BuildContext c)=>AlertDialog(title:Text(widget.name),content:SizedBox(width:360,height:300,child:Column(children:[Expanded(child:ListView(children:messages.map((m)=>Align(alignment:Alignment.centerRight,child:Container(margin:const EdgeInsets.all(4),padding:const EdgeInsets.all(9),decoration:BoxDecoration(color:kCyan.withValues(alpha: .16),borderRadius:BorderRadius.circular(12)),child:Text(m)))).toList()),),TextField(controller:controller,decoration:InputDecoration(hintText:'اكتب رسالة',suffixIcon:IconButton(onPressed:(){if(controller.text.trim().isNotEmpty)setState((){messages.add(controller.text.trim());controller.clear();});},icon:const Icon(Icons.send))))])));}

class ProfilePage extends StatelessWidget{const ProfilePage({super.key});@override Widget build(BuildContext c)=>AnimatedBuilder(animation:n,builder:(_,__)=>ListView(padding:const EdgeInsets.fromLTRB(16,48,16,30),children:[Row(children:[const NLogo(size:66),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(n.name.isEmpty?'N User':n.name,style:const TextStyle(fontSize:23,fontWeight:FontWeight.w900)),Row(children:[Text('@${n.username.isEmpty?'n_user':n.username}',style:const TextStyle(color:Colors.white54)),const SizedBox(width:5),const Icon(Icons.verified,color:kCyan,size:17)])])),IconButton(onPressed:()=>_settings(c),icon:const Icon(Icons.settings_outlined))]),const SizedBox(height:18),Text(n.bio),const SizedBox(height:20),Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_Stat('${n.posts.where((p)=>p.handle=='@${n.username}').length}','المنشورات'),const _Stat('0','المتابعون'),_Stat('${n.following.length}','المتابَعون'),_Stat('${n.coins}','N Coins')]),const SizedBox(height:20),Card(child:ListTile(leading:const Icon(Icons.shield_outlined,color:kCyan),title:const Text('الحماية العمرية'),subtitle:Text('العمر المسجل: ${n.age} سنة • ${n.adultEligible?'مؤهل':'غير مؤهل'} لمحتوى +21'))),Card(child:ListTile(leading:const Icon(Icons.card_giftcard,color:kPink),title:const Text('العملات والهدايا'),subtitle:Text('${n.coins} N Coins'),onTap:()=>_wallet(c))),Card(child:const ListTile(leading:Icon(Icons.live_tv,color:kPink),title:Text('البث المباشر'),subtitle:Text('ابدأ بثاً وتفاعل مع جمهورك'))),Card(child:const ListTile(leading:Icon(Icons.notifications_outlined),title:Text('الإشعارات'),subtitle:Text('الإعجابات والمتابعات والتعليقات'))),const SizedBox(height:8),OutlinedButton.icon(onPressed:(){n.logout();Navigator.pushAndRemoveUntil(c,MaterialPageRoute(builder:(_)=>const AuthPage()),(_)=>false);},icon:const Icon(Icons.logout),label:const Text('تسجيل الخروج'))]));void _wallet(BuildContext c)=>showModalBottomSheet(context:c,backgroundColor:kCard,builder:(_)=>SafeArea(child:Wrap(children:[const ListTile(title:Text('محفظة N',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900))),ListTile(leading:const Icon(Icons.add_circle,color:kCyan),title:const Text('شراء 1,000 N Coins'),onTap:(){n.addCoins(1000);Navigator.pop(c);}),const ListTile(leading:Icon(Icons.card_giftcard,color:kPink),title:Text('الهدايا وإرسالها'))])));void _settings(BuildContext c)=>showModalBottomSheet(context:c,backgroundColor:kCard,builder:(_)=>SafeArea(child:Wrap(children:[const ListTile(title:Text('الإعدادات',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900))),const ListTile(leading:Icon(Icons.lock_outline),title:Text('الخصوصية والأمان')),const ListTile(leading:Icon(Icons.language),title:Text('اللغة: العربية')),const ListTile(leading:Icon(Icons.dark_mode_outlined),title:Text('المظهر: داكن'))])));}
class _Stat extends StatelessWidget{const _Stat(this.value,this.label);final String value,label;@override Widget build(BuildContext c)=>Column(children:[Text(value,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w900)),Text(label,style:const TextStyle(fontSize:11,color:Colors.white54))]);}
